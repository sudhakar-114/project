from cryptography.fernet import Fernet
import os

# Set your master password here
MASTER_PASSWORD = "admin123"

# Generate encryption key (only once)
def create_key():
    if not os.path.exists("key.key"):
        key = Fernet.generate_key()
        with open("key.key", "wb") as key_file:
            key_file.write(key)

# Load encryption key
def load_key():
    return open("key.key", "rb").read()

# Encrypt the password
def encrypt(password):
    key = load_key()
    return Fernet(key).encrypt(password.encode()).decode()

# Decrypt the password
def decrypt(encrypted_password):
    key = load_key()
    return Fernet(key).decrypt(encrypted_password.encode()).decode()

# Save a new password entry
def save_password(site, username, password):
    encrypted_pass = encrypt(password)
    with open("passwords.txt", "a") as file:
        file.write(f"{site} | {username} | {encrypted_pass}\n")
    print("Password saved!")

# Search for a saved password
def find_password(site):
    if not os.path.exists("passwords.txt"):
        print("No passwords saved yet.")
        return

    with open("passwords.txt", "r") as file:
        found = False
        for line in file:
            s, u, p = line.strip().split(" | ")
            if s.lower() == site.lower():
                decrypted_pass = decrypt(p)
                print(f"\nWebsite: {s}")
                print(f"Username: {u}")
                print(f"Encrypted Password: {p}")
                print(f"Decrypted Password: {decrypted_pass}")
                found = True
                break
        if not found:
            print("Password not found.")

# Main menu
def menu():
    create_key()

    print("=== Welcome to the Password Manager ===")
    master = input("Enter Master Password: ")

    if master != MASTER_PASSWORD:
        print("Wrong master password! Access denied.")
        return

    while True:
        print("\n== Menu ==")
        print("1. Save new password")
        print("2. Find a saved password")
        print("3. Exit")

        choice = input("Choose (1/2/3): ")

        if choice == "1":
            site = input("Website: ")
            username = input("Username: ")
            password = input("Password: ")
            save_password(site, username, password)
        elif choice == "2":
            site = input("Enter website to search: ")
            find_password(site)
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid option. Try again.")

# Run the app
menu()
